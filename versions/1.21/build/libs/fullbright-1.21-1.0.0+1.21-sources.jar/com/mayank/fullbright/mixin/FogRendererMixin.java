package com.mayank.fullbright.mixin;

import com.mayank.fullbright.LightingManager;
import net.minecraft.class_4184;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_758.class)
public class FogRendererMixin {

    @Inject(method = "setupFog", at = @At("RETURN"))
    private static void onSetupFog(
            class_4184 camera,
            class_758.class_4596 fogMode,
            float renderDistance,
            boolean isFoggy,
            float tickDelta,
            CallbackInfo ci
    ) {
        if (!LightingManager.noFog) return;

        class_758.method_23792();
    }
}
