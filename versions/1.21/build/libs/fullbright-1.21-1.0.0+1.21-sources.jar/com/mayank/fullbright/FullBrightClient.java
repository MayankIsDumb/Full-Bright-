package com.mayank.fullbright;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class FullBrightClient implements ClientModInitializer {
    public static class_304 CONFIG_KEY;

    private static boolean lastTogglePressed = false;
    private static boolean lastNoFogPressed = false;

    @Override
    public void onInitializeClient() {
        LightingManager.load();

        CONFIG_KEY = new class_304(
            "key.fullbright.config",
            class_3675.class_307.field_1668,
            LightingManager.keyConfig,
            class_304.field_32137
        );
        KeyBindingHelper.registerKeyBinding(CONFIG_KEY);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Don't process keybinds when a screen is open (chat, sign, book, etc.)
            if (client.field_1755 != null) {
                lastTogglePressed = false;
                lastNoFogPressed = false;
                return;
            }

            long window = client.method_22683().method_4490();

            int currentToggleKey = LightingManager.keyToggle;
            int currentNoFogKey = LightingManager.keyNoFog;

            boolean togglePressed = GLFW.glfwGetKey(window, currentToggleKey) == GLFW.GLFW_PRESS;
            if (togglePressed && !lastTogglePressed) {
                FullBright.toggle();
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(
                        net.minecraft.class_2561.method_43470(
                            "Fullbright: " + (LightingManager.isActive() ? "ON" : "OFF")
                        ),
                        true
                    );
                }
            }
            lastTogglePressed = togglePressed;

            boolean noFogPressed = GLFW.glfwGetKey(window, currentNoFogKey) == GLFW.GLFW_PRESS;
            if (noFogPressed && !lastNoFogPressed) {
                LightingManager.toggleNoFog();
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(
                        net.minecraft.class_2561.method_43470(
                            "No Fog: " + (LightingManager.noFog ? "ON" : "OFF")
                        ),
                        true
                    );
                }
            }
            lastNoFogPressed = noFogPressed;

            while (CONFIG_KEY.method_1436()) {
                client.method_1507(new ConfigScreen(client.field_1755));
            }
        });
    }
}
