package com.mayank.fullbright;

import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public class ConfigScreen extends class_437 {
    private final class_437 parent;
    private class_4185 fullBrightButton;
    private class_4185 noFogButton;
    private class_4185 toggleKeyButton;
    private class_4185 noFogKeyButton;

    private boolean bindingToggle = false;
    private boolean bindingNoFog = false;
    private int bindCooldown = 0;

    // Brightness slider positions
    private int sliderStartX, sliderEndX, sliderY;
    private boolean draggingSlider = false;

    public ConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Afkz studios Fullbright"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int startY = this.field_22790 / 4;

        sliderStartX = centerX - 100;
        sliderEndX = centerX + 100;
        sliderY = startY + 95;

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Afkz studios Fullbright"),
            btn -> { }
        ).method_46433(centerX - 80, startY).method_46437(160, 20).method_46431());

        fullBrightButton = this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Fullbright: " + (LightingManager.isActive() ? "ON" : "OFF")),
            btn -> {
                LightingManager.toggleActive();
                fullBrightButton.method_25355(class_2561.method_43470("Fullbright: " + (LightingManager.isActive() ? "ON" : "OFF")));
                if (LightingManager.isActive() && this.field_22787.field_1769 != null) {
                    this.field_22787.field_1769.method_3279();
                }
            }
        ).method_46433(centerX - 80, startY + 25).method_46437(160, 20).method_46431());

        noFogButton = this.method_37063(class_4185.method_46430(
            class_2561.method_43470("No Fog: " + (LightingManager.noFog ? "ON" : "OFF")),
            btn -> {
                LightingManager.toggleNoFog();
                noFogButton.method_25355(class_2561.method_43470("No Fog: " + (LightingManager.noFog ? "ON" : "OFF")));
            }
        ).method_46433(centerX - 80, startY + 50).method_46437(160, 20).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Brightness: " + LightingManager.brightIntensity),
            btn -> { }
        ).method_46433(centerX - 80, startY + 75).method_46437(160, 20).method_46431());

        toggleKeyButton = this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Toggle Key: " + GLFW.glfwGetKeyName(LightingManager.keyToggle, 0)),
            btn -> {
                bindingToggle = true;
                bindingNoFog = false;
                toggleKeyButton.method_25355(class_2561.method_43470("Press a key..."));
            }
        ).method_46433(centerX - 80, startY + 120).method_46437(160, 20).method_46431());

        noFogKeyButton = this.method_37063(class_4185.method_46430(
            class_2561.method_43470("No Fog Key: " + GLFW.glfwGetKeyName(LightingManager.keyNoFog, 0)),
            btn -> {
                bindingNoFog = true;
                bindingToggle = false;
                noFogKeyButton.method_25355(class_2561.method_43470("Press a key..."));
            }
        ).method_46433(centerX - 80, startY + 145).method_46437(160, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float delta) {
        guiGraphics.method_25294(0, 0, this.field_22789, this.field_22790, 0xC0101010);
        guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);

        guiGraphics.method_25294(sliderStartX, sliderY, sliderEndX, sliderY + 10, 0xFF404040);
        int filledWidth = (int) ((LightingManager.brightIntensity / 15.0) * (sliderEndX - sliderStartX));
        guiGraphics.method_25294(sliderStartX, sliderY, sliderStartX + filledWidth, sliderY + 10, 0xFF00AAFF);
        int handleX = sliderStartX + filledWidth - 2;
        guiGraphics.method_25294(handleX, sliderY - 2, handleX + 4, sliderY + 12, 0xFFFFFFFF);

        super.method_25394(guiGraphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25403(class_11909 event, double deltaX, double deltaY) {
        double mouseX = event.comp_4798();
        double mouseY = event.comp_4799();
        if (draggingSlider || (mouseX >= sliderStartX && mouseX <= sliderEndX && mouseY >= sliderY && mouseY <= sliderY + 10)) {
            draggingSlider = true;
            double ratio = (mouseX - sliderStartX) / (double) (sliderEndX - sliderStartX);
            LightingManager.brightIntensity = (int) Math.round(Math.max(0, Math.min(15, ratio * 15)));
            if (LightingManager.isActive()) LightingManager.applyGamma();
            return true;
        }
        return super.method_25403(event, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(class_11909 event) {
        draggingSlider = false;
        return super.method_25406(event);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX >= sliderStartX && mouseX <= sliderEndX && mouseY >= sliderY - 5 && mouseY <= sliderY + 15) {
            LightingManager.brightIntensity = Math.max(0, Math.min(15, LightingManager.brightIntensity + (int) Math.signum(verticalAmount)));
            if (LightingManager.isActive()) LightingManager.applyGamma();
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (bindCooldown > 0) return true;

        if (bindingToggle) {
            LightingManager.keyToggle = event.comp_4795();
            bindingToggle = false;
            toggleKeyButton.method_25355(class_2561.method_43470("Toggle Key: " + GLFW.glfwGetKeyName(event.comp_4795(), 0)));
            return true;
        }

        if (bindingNoFog) {
            LightingManager.keyNoFog = event.comp_4795();
            bindingNoFog = false;
            noFogKeyButton.method_25355(class_2561.method_43470("No Fog Key: " + GLFW.glfwGetKeyName(event.comp_4795(), 0)));
            return true;
        }

        return super.method_25404(event);
    }

    @Override
    public void method_25393() {
        if (bindCooldown > 0) bindCooldown--;
    }

    @Override
    public boolean method_25421() {
        return true;
    }

    @Override
    public void method_25432() {
        LightingManager.save();
    }
}
