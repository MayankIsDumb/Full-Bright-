package com.mayank.fullbright.mixin;

import com.mayank.fullbright.LightingManager;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_7285;
import net.minecraft.class_758;
import net.minecraft.class_9779;
import org.joml.Vector4f;
import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_758.class)
public abstract class FogRendererMixin {

    @Inject(
        method = "setupFog(Lnet/minecraft/client/Camera;ILnet/minecraft/client/DeltaTracker;FLnet/minecraft/client/multiplayer/ClientLevel;)Lorg/joml/Vector4f;",
        at = @At(value = "FIELD", target = "Lnet/minecraft/client/renderer/fog/FogData;renderDistanceEnd:F", ordinal = 0, shift = At.Shift.AFTER)
    )
    private void onSetupFog(class_4184 camera, int renderDistance, class_9779 deltaTracker, float viewDistance, class_638 level, CallbackInfoReturnable<Vector4f> cir, @Local class_7285 fogData) {
        if (LightingManager.noFog) {
            fogData.field_60582 = Float.MAX_VALUE;
            fogData.field_60584 = Float.MAX_VALUE;
            fogData.field_60583 = Float.MAX_VALUE;
            fogData.field_60585 = Float.MAX_VALUE;
            fogData.field_60099 = viewDistance;

            int cloudDistance = class_310.method_1551().field_1690.method_71270().method_41753();
            fogData.field_60100 = cloudDistance * 16.0f;
        }
    }
}
