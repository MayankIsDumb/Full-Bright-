package com.mayank.fullbright.mixin;

import net.minecraft.class_310;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_7172.class)
public class OverrideIllegalMixin<T> {
    @Shadow
    T value;

    @Inject(method = "set", at = @At("HEAD"), cancellable = true)
    private void overrideSet(T newValue, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();

        if (mc.field_1690 != null) {
            class_7172<?> option = mc.field_1690.method_42473();

            if ((Object) this == option) {
                this.value = newValue;
                ci.cancel();
            }
        }
    }
}
